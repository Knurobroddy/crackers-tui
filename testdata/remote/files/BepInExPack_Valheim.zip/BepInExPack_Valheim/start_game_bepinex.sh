#!/bin/sh
echo fake
